#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void t_ext(char *base_name);
/* Recebe um ponteiro para o conteudo do nome base do arquivo e retira a extensão. */
